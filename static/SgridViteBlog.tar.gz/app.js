"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var main_1 = require("sgridnode/build/main");
var src_1 = require("./src");
var static_1 = require("./src/interceptor/static");
function boost() {
    var ctx = (0, main_1.NewSgridServerCtx)();
    new static_1.SpaFile().use(ctx);
    var f = new src_1.FrameworkController(ctx);
    ctx.use("/api", f.router);
    (0, main_1.NewSgridServer)(ctx);
}
boost();
//# sourceMappingURL=app.js.map