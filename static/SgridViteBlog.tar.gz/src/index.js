"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FrameworkController = void 0;
var framework_controller_1 = require("./framework/framework.controller");
Object.defineProperty(exports, "FrameworkController", { enumerable: true, get: function () { return framework_controller_1.FrameworkController; } });
//# sourceMappingURL=index.js.map