"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateMiddleWare = exports.Handler = void 0;
var main_1 = require("sgridnode/build/main");
var express_validator_1 = require("express-validator");
function Handler(e) {
    return main_1.Resp.Error(-9999, e.message, null);
}
exports.Handler = Handler;
function validateMiddleWare(req, res, next) {
    var errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        res.json(main_1.Resp.Error(-1, "validateError", errors.array()));
        return res.end();
    }
    next();
}
exports.validateMiddleWare = validateMiddleWare;
//# sourceMappingURL=error.js.map